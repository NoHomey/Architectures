#ifndef _sound_color_H
#define _sound_color_H
#include <Arduino.h>
class sound_color {
 public:
  animation(const uint8_t& f1, const uint8_t& f2, const uint8_t& f3, const uint8_t& f4);
  void set(void);
  void begin(void);
 private:
  uint16_t _blue;
  uint16_t _red;
  uint16_t _green;
  uint8_t _f1;
  uint8_t _f2;
  uint8_t _f3;
  uint8_t _f4;
};
#endif
