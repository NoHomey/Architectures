/*************************************************** 
  This is a library for our Adafruit 24-channel PWM/LED driver

  Pick one up today in the adafruit shop!
  ------> http://www.adafruit.com/products/1429

  These drivers uses SPI to communicate, 3 pins are required to  
  interface: Data, Clock and Latch. The boards are chainable

  Adafruit invests time and resources providing this open source code, 
  please support Adafruit and open-source hardware by purchasing 
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.  
  BSD license, all text above must be included in any redistribution
 ****************************************************/
#include <Adafruit_TLC5947.h>

Adafruit_TLC5947::Adafruit_TLC5947(int n, int c, int d, int l) {
  numdrivers = n;
  _clk = c;
  _dat = d;
  _lat = l;
  pwmbuffer = (int *)calloc(2, 24*n);
}

void Adafruit_TLC5947::write(void) {
  digitalWrite(_lat, LOW);
  // 24 channels per TLC5974
  for (int c = 0; c < 24*numdrivers; c++) {
    // 12 bits per channel, send MSB first
    for (int b = 11; b > -1; b--) {
      digitalWrite(_clk, LOW);
      if (pwmbuffer[c] & (1 << b))  { 
      	Serial.println(1);	
        digitalWrite(_dat, HIGH);
      } else {
      	Serial.println(0);
        digitalWrite(_dat, LOW);
	}
      digitalWrite(_clk, HIGH);
    }
  }
  digitalWrite(_clk, LOW);
  digitalWrite(_lat, HIGH);  
  digitalWrite(_lat, LOW);
}

void Adafruit_TLC5947::setPWM(int chan, int pwm) {
  if (pwm > 4095) pwm = 4095;
  if (chan > 24*numdrivers) return;
  pwmbuffer[chan] = pwm;  
}

void Adafruit_TLC5947::setLED(int lednum, int r, int g, int b) {
  setPWM(lednum*3, b);
  setPWM(lednum*3+1, r);
  setPWM(lednum*3+2, g);
}

boolean Adafruit_TLC5947::begin() {
  if (!pwmbuffer) return false;
  pinMode(_clk, OUTPUT);
  pinMode(_dat, OUTPUT);
  pinMode(_lat, OUTPUT);
  digitalWrite(_lat, LOW);
  return true;
}
