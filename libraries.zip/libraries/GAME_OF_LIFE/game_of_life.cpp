#include <game_of_life.h>
game_of_life::game_of_life(const uint8_t& d, Adafruit_TLC5947* tlc, const uint8_t& c) {
  _d = d;
  _flag = 0;
  _arr = (bool**) calloc(_d, sizeof(bool*));
  _tlc = tlc;
  _pwm = 0;
  _color = c;
  for(int8_t i = 0;i < _d;++i)
  	_arr[i] = (bool*) calloc(_d, sizeof(bool));
}

uint16_t game_of_life::convert(const uint8_t& x, const uint8_t& y) {
	return (x*8 + y)*3 + _color;
}

void game_of_life::set() {
  _pwm = 40;
  for(int8_t i = 0;i < _d;++i) {
    for(int8_t j = 0;j < _d;++j)
      _arr[i][j] ? _tlc->setPWM(convert(i, j), _pwm) : _tlc->setPWM(convert(i, j), 0);
  }
  _tlc->write();
}

void game_of_life::begin() {
  _flag = 1;
  uint8_t s = 30;
  for(int8_t i = 0;i < s;++i)
    _arr[random(_d)][random(_d)] = 1;
  set();
}

void game_of_life::progress() {
  _flag = 0;
   int8_t neibrs = 0;
   for(int8_t i = 0;i < _d;++i) {
    for(int8_t j = 0;j < _d;++j) {
      neibrs = 0;
      neibrs += (((i - 1) < 0) ||  ((j - 1) < 0)) ? 0 : _arr[i - 1][j - 1];
      neibrs += ((i - 1) < 0) ? 0 : _arr[i - 1][j];
      neibrs += (((i - 1) < 0) ||  ((j + 1) > 7)) ? 0 : _arr[i - 1][j + 1];
      neibrs += ((j + 1) > 7) ? 0 : _arr[i][j + 1];
      neibrs += (((i + 1) > 7) ||  ((j + 1) > 7)) ? 0 : _arr[i + 1][j + 1];
      neibrs += ((i + 1) > 7) ? 0 : _arr[i + 1][j];
      neibrs += (((i + 1) > 7) ||  ((j - 1) < 7)) ? 0 : _arr[i + 1][j - 1];
      neibrs += ((j - 1) < 0) ? 0 : _arr[i][j - 1];
      if(neibrs == 3) {
      	_arr[i][j] = 1;
      	_flag = 1;
      }
      if((neibrs > 3) || (neibrs < 2)) {
      	_arr[i][j] = 0;
      	_flag = 1;
      }
    }
  }
    set();
}


