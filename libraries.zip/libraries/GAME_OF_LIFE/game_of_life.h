#ifndef _GAME_OF_LIFE_H
#define _GAME_OF_LIFE_H
#include "Adafruit_TLC5947.h"
#include <Arduino.h>

class game_of_life {
 public:
  game_of_life(const uint8_t& d, Adafruit_TLC5947* tlc, const uint8_t& c);
  void begin(void);
  void progress(void);
  void set(void);
  uint16_t convert(const uint8_t& x, const uint8_t& y);
 private:
  uint8_t _d;
  bool _flag;
  bool** _arr;
  Adafruit_TLC5947* _tlc;
  uint16_t _pwm;
  uint8_t _color;
};

#endif
